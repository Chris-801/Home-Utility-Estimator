// Client-safe address utilities (no API keys)
interface UtilityRateData {
  electricityRate: number
  gasRate: number
  waterRate: number
  sewerRate: number
  trashRate: number
  internetRate: number
  utilityCompany?: string
  climateZone?: string
}

// Public utility rate database - safe to expose to client
const utilityRatesByZip: Record<string, UtilityRateData> = {
  "62701": {
    electricityRate: 0.13,
    gasRate: 0.95,
    waterRate: 0.004,
    sewerRate: 42,
    trashRate: 28,
    internetRate: 65,
    utilityCompany: "Ameren Illinois",
    climateZone: "5A",
  },
  "60601": {
    electricityRate: 0.15,
    gasRate: 1.05,
    waterRate: 0.005,
    sewerRate: 55,
    trashRate: 35,
    internetRate: 75,
    utilityCompany: "ComEd",
    climateZone: "5A",
  },
  "90210": {
    electricityRate: 0.28,
    gasRate: 1.35,
    waterRate: 0.008,
    sewerRate: 85,
    trashRate: 45,
    internetRate: 90,
    utilityCompany: "Los Angeles Department of Water and Power",
    climateZone: "3B",
  },
  "78701": {
    electricityRate: 0.12,
    gasRate: 1.0,
    waterRate: 0.006,
    sewerRate: 45,
    trashRate: 30,
    internetRate: 65,
    utilityCompany: "Austin Energy",
    climateZone: "2A",
  },
  "98101": {
    electricityRate: 0.11,
    gasRate: 1.15,
    waterRate: 0.007,
    sewerRate: 70,
    trashRate: 40,
    internetRate: 80,
    utilityCompany: "Seattle City Light",
    climateZone: "4C",
  },
  "10001": {
    electricityRate: 0.22,
    gasRate: 1.25,
    waterRate: 0.005,
    sewerRate: 65,
    trashRate: 35,
    internetRate: 75,
    utilityCompany: "Consolidated Edison",
    climateZone: "4A",
  },
  "33101": {
    electricityRate: 0.14,
    gasRate: 1.1,
    waterRate: 0.004,
    sewerRate: 50,
    trashRate: 25,
    internetRate: 70,
    utilityCompany: "Florida Power & Light",
    climateZone: "1A",
  },
}

export function getUtilityRatesByAddress(address: any): UtilityRateData | null {
  const zipCode = address.zipCode
  return utilityRatesByZip[zipCode] || null
}

export function getClimateAdjustment(climateZone: string, homeDetails: any): number {
  // Climate zone adjustments for heating/cooling
  const adjustments: Record<string, number> = {
    "1A": 0.7, // Very Hot-Humid (Miami)
    "2A": 0.8, // Hot-Humid (Houston)
    "3A": 0.9, // Warm-Humid (Atlanta)
    "3B": 0.85, // Warm-Dry (Los Angeles)
    "4A": 1.0, // Mixed-Humid (New York)
    "4C": 1.05, // Marine (Seattle)
    "5A": 1.1, // Cool-Humid (Chicago)
    "6A": 1.2, // Cold-Humid (Minneapolis)
    "7": 1.3, // Very Cold (Duluth)
  }

  return adjustments[climateZone] || 1.0
}

// Get all available ZIP codes for testing/demo purposes
export function getAvailableZipCodes(): string[] {
  return Object.keys(utilityRatesByZip)
}

// Get utility company info by ZIP code
export function getUtilityCompanyByZip(zipCode: string): string | null {
  const rates = utilityRatesByZip[zipCode]
  return rates?.utilityCompany || null
}

// Get climate zone by ZIP code
export function getClimateZoneByZip(zipCode: string): string | null {
  const rates = utilityRatesByZip[zipCode]
  return rates?.climateZone || null
}
