export interface ValidationError {
  field: string
  message: string
}

export function validateHomeDetails(details: any): ValidationError[] {
  const errors: ValidationError[] = []

  if (!details.squareFootage || details.squareFootage < 100) {
    errors.push({ field: "squareFootage", message: "Square footage must be at least 100" })
  }

  if (!details.occupants || details.occupants < 1) {
    errors.push({ field: "occupants", message: "Must have at least 1 occupant" })
  }

  if (!details.bedrooms || details.bedrooms < 0) {
    errors.push({ field: "bedrooms", message: "Bedrooms cannot be negative" })
  }

  if (!details.bathrooms || details.bathrooms < 0) {
    errors.push({ field: "bathrooms", message: "Bathrooms cannot be negative" })
  }

  return errors
}
