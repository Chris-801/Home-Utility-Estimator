// Client-safe geocoding types and utilities (no API keys exposed)

export interface AddressSuggestion {
  id: string
  fullAddress: string
  street: string
  city: string
  state: string
  zipCode: string
  country?: string
  coordinates?: { lat: number; lng: number }
  utilityCompany?: string
  climateZone?: string
  confidence?: number
  source?: string
}

interface GeocodeResponse {
  suggestions: AddressSuggestion[]
  status: "success" | "error" | "rate_limit" | "no_results"
  message?: string
}

// Client-safe utility functions that don't require API keys
export function getUtilityRatesByZip(zipCode: string) {
  // This data can be safely exposed to the client
  const utilityRates: Record<string, any> = {
    "62701": {
      electricityRate: 0.13,
      gasRate: 0.95,
      waterRate: 0.004,
      sewerRate: 42,
      trashRate: 28,
      internetRate: 65,
      utilityCompany: "Ameren Illinois",
      climateZone: "5A",
    },
    "60601": {
      electricityRate: 0.15,
      gasRate: 1.05,
      waterRate: 0.005,
      sewerRate: 55,
      trashRate: 35,
      internetRate: 75,
      utilityCompany: "ComEd",
      climateZone: "5A",
    },
    "90210": {
      electricityRate: 0.28,
      gasRate: 1.35,
      waterRate: 0.008,
      sewerRate: 85,
      trashRate: 45,
      internetRate: 90,
      utilityCompany: "Los Angeles Department of Water and Power",
      climateZone: "3B",
    },
    "78701": {
      electricityRate: 0.12,
      gasRate: 1.0,
      waterRate: 0.006,
      sewerRate: 45,
      trashRate: 30,
      internetRate: 65,
      utilityCompany: "Austin Energy",
      climateZone: "2A",
    },
    "98101": {
      electricityRate: 0.11,
      gasRate: 1.15,
      waterRate: 0.007,
      sewerRate: 70,
      trashRate: 40,
      internetRate: 80,
      utilityCompany: "Seattle City Light",
      climateZone: "4C",
    },
    "10001": {
      electricityRate: 0.22,
      gasRate: 1.25,
      waterRate: 0.005,
      sewerRate: 65,
      trashRate: 35,
      internetRate: 75,
      utilityCompany: "Consolidated Edison",
      climateZone: "4A",
    },
    "33101": {
      electricityRate: 0.14,
      gasRate: 1.1,
      waterRate: 0.004,
      sewerRate: 50,
      trashRate: 25,
      internetRate: 70,
      utilityCompany: "Florida Power & Light",
      climateZone: "1A",
    },
  }

  return utilityRates[zipCode] || null
}

export function getClimateAdjustment(climateZone: string): number {
  const adjustments: Record<string, number> = {
    "1A": 0.7, // Very Hot-Humid (Miami)
    "2A": 0.8, // Hot-Humid (Houston)
    "3A": 0.9, // Warm-Humid (Atlanta)
    "3B": 0.85, // Warm-Dry (Los Angeles)
    "4A": 1.0, // Mixed-Humid (New York)
    "4C": 1.05, // Marine (Seattle)
    "5A": 1.1, // Cool-Humid (Chicago)
    "6A": 1.2, // Cold-Humid (Minneapolis)
    "7": 1.3, // Very Cold (Duluth)
  }

  return adjustments[climateZone] || 1.0
}

// Mock geocoding service for development (no API keys needed)
export class MockGeocodingService {
  async searchAddresses(query: string): Promise<GeocodeResponse> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    if (query.length < 3) {
      return { suggestions: [], status: "no_results", message: "Query too short" }
    }

    // Enhanced mock database with more realistic addresses
    const mockDatabase: AddressSuggestion[] = [
      {
        id: "mock_1",
        fullAddress: "123 Main Street, Springfield, IL 62701, USA",
        street: "123 Main Street",
        city: "Springfield",
        state: "IL",
        zipCode: "62701",
        country: "USA",
        coordinates: { lat: 39.7817, lng: -89.6501 },
        utilityCompany: "Ameren Illinois",
        climateZone: "5A",
        confidence: 0.95,
        source: "mock",
      },
      {
        id: "mock_2",
        fullAddress: "456 Oak Avenue, Chicago, IL 60601, USA",
        street: "456 Oak Avenue",
        city: "Chicago",
        state: "IL",
        zipCode: "60601",
        country: "USA",
        coordinates: { lat: 41.8781, lng: -87.6298 },
        utilityCompany: "ComEd",
        climateZone: "5A",
        confidence: 0.92,
        source: "mock",
      },
      {
        id: "mock_3",
        fullAddress: "789 Pine Street, Beverly Hills, CA 90210, USA",
        street: "789 Pine Street",
        city: "Beverly Hills",
        state: "CA",
        zipCode: "90210",
        country: "USA",
        coordinates: { lat: 34.0901, lng: -118.4065 },
        utilityCompany: "Los Angeles Department of Water and Power",
        climateZone: "3B",
        confidence: 0.88,
        source: "mock",
      },
      {
        id: "mock_4",
        fullAddress: "321 Elm Drive, Austin, TX 78701, USA",
        street: "321 Elm Drive",
        city: "Austin",
        state: "TX",
        zipCode: "78701",
        country: "USA",
        coordinates: { lat: 30.2672, lng: -97.7431 },
        utilityCompany: "Austin Energy",
        climateZone: "2A",
        confidence: 0.9,
        source: "mock",
      },
      {
        id: "mock_5",
        fullAddress: "654 Maple Lane, Seattle, WA 98101, USA",
        street: "654 Maple Lane",
        city: "Seattle",
        state: "WA",
        zipCode: "98101",
        country: "USA",
        coordinates: { lat: 47.6062, lng: -122.3321 },
        utilityCompany: "Seattle City Light",
        climateZone: "4C",
        confidence: 0.87,
        source: "mock",
      },
      {
        id: "mock_6",
        fullAddress: "987 Broadway, New York, NY 10001, USA",
        street: "987 Broadway",
        city: "New York",
        state: "NY",
        zipCode: "10001",
        country: "USA",
        coordinates: { lat: 40.7505, lng: -73.9934 },
        utilityCompany: "Consolidated Edison",
        climateZone: "4A",
        confidence: 0.93,
        source: "mock",
      },
    ]

    // Enhanced filtering and ranking
    const filtered = mockDatabase.filter((address) => {
      const searchTerms = query.toLowerCase().split(" ")
      const addressText = address.fullAddress.toLowerCase()

      return searchTerms.some(
        (term) =>
          addressText.includes(term) ||
          address.street.toLowerCase().includes(term) ||
          address.city.toLowerCase().includes(term) ||
          address.zipCode.includes(term),
      )
    })

    // Sort by relevance
    const sorted = filtered
      .sort((a, b) => {
        const aScore = this.calculateRelevanceScore(a, query)
        const bScore = this.calculateRelevanceScore(b, query)
        return bScore - aScore
      })
      .slice(0, 5)

    return { suggestions: sorted, status: "success", source: "mock" }
  }

  private calculateRelevanceScore(address: AddressSuggestion, query: string): number {
    const lowerQuery = query.toLowerCase()
    let score = 0

    // Exact matches get higher scores
    if (address.street.toLowerCase().includes(lowerQuery)) score += 10
    if (address.city.toLowerCase().includes(lowerQuery)) score += 8
    if (address.zipCode.includes(query)) score += 6
    if (address.state.toLowerCase().includes(lowerQuery)) score += 4

    // Partial matches get lower scores
    if (address.fullAddress.toLowerCase().includes(lowerQuery)) score += 2

    // Boost score based on confidence
    score += (address.confidence || 0.5) * 5

    return score
  }

  async reverseGeocode(lat: number, lng: number): Promise<AddressSuggestion | null> {
    // Mock reverse geocoding
    return {
      id: "reverse_mock",
      fullAddress: "Current Location - 123 Your Street, Your City, ST 12345",
      street: "123 Your Street",
      city: "Your City",
      state: "ST",
      zipCode: "12345",
      coordinates: { lat, lng },
      confidence: 0.8,
      source: "mock_reverse",
    }
  }
}

// Export a client-safe mock service for development
export const mockGeocodingService = new MockGeocodingService()
