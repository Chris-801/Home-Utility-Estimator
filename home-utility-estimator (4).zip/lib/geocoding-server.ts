"use server"

// Server-side geocoding service - API keys are secure here
interface GeocodingConfig {
  provider: "google" | "mapbox" | "opencage" | "here" | "mock"
  enableCaching?: boolean
}

export interface AddressSuggestion {
  id: string
  fullAddress: string
  street: string
  city: string
  state: string
  zipCode: string
  country?: string
  coordinates?: { lat: number; lng: number }
  utilityCompany?: string
  climateZone?: string
  confidence?: number
  source?: string
}

interface GeocodeResponse {
  suggestions: AddressSuggestion[]
  status: "success" | "error" | "rate_limit" | "no_results"
  message?: string
}

// Enhanced utility company database
const UTILITY_COMPANIES_DB: Record<string, { name: string; climateZone: string }> = {
  // Illinois
  "60601": { name: "ComEd", climateZone: "5A" },
  "60602": { name: "ComEd", climateZone: "5A" },
  "62701": { name: "Ameren Illinois", climateZone: "5A" },
  "62702": { name: "City Water Light & Power", climateZone: "5A" },

  // California
  "90210": { name: "Los Angeles Department of Water and Power", climateZone: "3B" },
  "90211": { name: "Los Angeles Department of Water and Power", climateZone: "3B" },
  "94102": { name: "Pacific Gas & Electric", climateZone: "3C" },
  "94103": { name: "Pacific Gas & Electric", climateZone: "3C" },

  // Texas
  "78701": { name: "Austin Energy", climateZone: "2A" },
  "78702": { name: "Austin Energy", climateZone: "2A" },
  "77001": { name: "CenterPoint Energy", climateZone: "2A" },
  "77002": { name: "CenterPoint Energy", climateZone: "2A" },

  // New York
  "10001": { name: "Consolidated Edison", climateZone: "4A" },
  "10002": { name: "Consolidated Edison", climateZone: "4A" },
  "10003": { name: "Consolidated Edison", climateZone: "4A" },

  // Florida
  "33101": { name: "Florida Power & Light", climateZone: "1A" },
  "33102": { name: "Florida Power & Light", climateZone: "1A" },
  "32801": { name: "Orlando Utilities Commission", climateZone: "2A" },

  // Washington
  "98101": { name: "Seattle City Light", climateZone: "4C" },
  "98102": { name: "Seattle City Light", climateZone: "4C" },
  "98201": { name: "Puget Sound Energy", climateZone: "4C" },
}

// Server-side configuration - API keys are secure here
const getGeocodingConfig = (): GeocodingConfig => {
  return {
    provider: (process.env.GEOCODING_PROVIDER as any) || "mock",
    enableCaching: process.env.NODE_ENV === "production",
  }
}

// Server-side API key access
const getApiKey = (provider: string): string | undefined => {
  switch (provider) {
    case "google":
      return process.env.GOOGLE_PLACES_API_KEY
    case "mapbox":
      return process.env.MAPBOX_ACCESS_TOKEN
    case "opencage":
      return process.env.OPENCAGE_API_KEY
    case "here":
      return process.env.HERE_API_KEY
    default:
      return undefined
  }
}

class ServerGeocodingService {
  private config: GeocodingConfig
  private cache: Map<string, GeocodeResponse> = new Map()

  constructor() {
    this.config = getGeocodingConfig()
  }

  async searchAddresses(query: string): Promise<GeocodeResponse> {
    if (query.length < 3) {
      return { suggestions: [], status: "no_results", message: "Query too short" }
    }

    // Check cache first
    if (this.config.enableCaching && this.cache.has(query)) {
      const cached = this.cache.get(query)!
      return { ...cached, source: "cache" }
    }

    try {
      const response = await this.searchWithProvider(query, this.config.provider)

      // Cache successful responses
      if (this.config.enableCaching && response.status === "success") {
        this.cache.set(query, response)
      }

      return response
    } catch (error) {
      console.error("Server geocoding error:", error)
      return { suggestions: [], status: "error", message: "Service unavailable" }
    }
  }

  private async searchWithProvider(query: string, provider: string): Promise<GeocodeResponse> {
    switch (provider) {
      case "google":
        return this.searchWithGoogle(query)
      case "mapbox":
        return this.searchWithMapbox(query)
      case "opencage":
        return this.searchWithOpenCage(query)
      case "here":
        return this.searchWithHere(query)
      default:
        return this.mockSearch(query)
    }
  }

  private async searchWithGoogle(query: string): Promise<GeocodeResponse> {
    const apiKey = getApiKey("google")
    if (!apiKey) {
      console.warn("Google API key not configured, falling back to mock")
      return this.mockSearch(query)
    }

    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(query)}&types=address&key=${apiKey}`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.status === "OK") {
        const suggestions = await Promise.all(
          data.predictions.slice(0, 5).map(async (prediction: any) => {
            const details = await this.getGooglePlaceDetails(prediction.place_id, apiKey)
            return this.parseGoogleResult(prediction, details)
          }),
        )

        return { suggestions, status: "success", source: "google" }
      } else {
        return { suggestions: [], status: "error", message: data.error_message || "Google API error" }
      }
    } catch (error) {
      console.error("Google geocoding failed:", error)
      return this.mockSearch(query) // Fallback to mock
    }
  }

  private async getGooglePlaceDetails(placeId: string, apiKey: string): Promise<any> {
    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=address_components,geometry&key=${apiKey}`
    const response = await fetch(url)
    const data = await response.json()
    return data.result
  }

  private parseGoogleResult(prediction: any, details: any): AddressSuggestion {
    const addressComponents = details?.address_components || []

    const getComponent = (type: string) => {
      const component = addressComponents.find((comp: any) => comp.types.includes(type))
      return component?.long_name || ""
    }

    const streetNumber = getComponent("street_number")
    const streetName = getComponent("route")
    const city = getComponent("locality") || getComponent("sublocality")
    const state = getComponent("administrative_area_level_1")
    const zipCode = getComponent("postal_code")
    const country = getComponent("country")

    const street = `${streetNumber} ${streetName}`.trim()
    const coordinates = details?.geometry?.location

    const utilityInfo = UTILITY_COMPANIES_DB[zipCode] || {}

    return {
      id: prediction.place_id,
      fullAddress: prediction.description,
      street,
      city,
      state,
      zipCode,
      country,
      coordinates: coordinates ? { lat: coordinates.lat, lng: coordinates.lng } : undefined,
      utilityCompany: utilityInfo.name,
      climateZone: utilityInfo.climateZone,
      confidence: 0.9,
      source: "google",
    }
  }

  private async searchWithMapbox(query: string): Promise<GeocodeResponse> {
    const apiKey = getApiKey("mapbox")
    if (!apiKey) {
      console.warn("Mapbox API key not configured, falling back to mock")
      return this.mockSearch(query)
    }

    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=${apiKey}&types=address&limit=5&country=us`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.features) {
        const suggestions = data.features.map((feature: any) => this.parseMapboxResult(feature))
        return { suggestions, status: "success", source: "mapbox" }
      } else {
        return { suggestions: [], status: "error", message: "Mapbox API error" }
      }
    } catch (error) {
      console.error("Mapbox geocoding failed:", error)
      return this.mockSearch(query) // Fallback to mock
    }
  }

  private parseMapboxResult(feature: any): AddressSuggestion {
    const context = feature.context || []
    const getContext = (type: string) => {
      const item = context.find((ctx: any) => ctx.id.startsWith(type))
      return item?.text || ""
    }

    const coordinates = feature.geometry?.coordinates
    const zipCode = getContext("postcode")
    const utilityInfo = UTILITY_COMPANIES_DB[zipCode] || {}

    return {
      id: feature.id,
      fullAddress: feature.place_name,
      street: feature.text || "",
      city: getContext("place"),
      state: getContext("region"),
      zipCode,
      country: getContext("country"),
      coordinates: coordinates ? { lat: coordinates[1], lng: coordinates[0] } : undefined,
      utilityCompany: utilityInfo.name,
      climateZone: utilityInfo.climateZone,
      confidence: feature.relevance || 0.8,
      source: "mapbox",
    }
  }

  private async searchWithOpenCage(query: string): Promise<GeocodeResponse> {
    const apiKey = getApiKey("opencage")
    if (!apiKey) {
      console.warn("OpenCage API key not configured, falling back to mock")
      return this.mockSearch(query)
    }

    const url = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(query)}&key=${apiKey}&limit=5&countrycode=us&no_annotations=1`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.results) {
        const suggestions = data.results.map((result: any) => this.parseOpenCageResult(result))
        return { suggestions, status: "success", source: "opencage" }
      } else {
        return { suggestions: [], status: "error", message: "OpenCage API error" }
      }
    } catch (error) {
      console.error("OpenCage geocoding failed:", error)
      return this.mockSearch(query) // Fallback to mock
    }
  }

  private parseOpenCageResult(result: any): AddressSuggestion {
    const components = result.components
    const zipCode = components.postcode
    const utilityInfo = UTILITY_COMPANIES_DB[zipCode] || {}

    return {
      id: `opencage_${result.geometry.lat}_${result.geometry.lng}`,
      fullAddress: result.formatted,
      street: `${components.house_number || ""} ${components.road || ""}`.trim(),
      city: components.city || components.town || components.village,
      state: components.state,
      zipCode,
      country: components.country,
      coordinates: { lat: result.geometry.lat, lng: result.geometry.lng },
      utilityCompany: utilityInfo.name,
      climateZone: utilityInfo.climateZone,
      confidence: result.confidence || 0.7,
      source: "opencage",
    }
  }

  private async searchWithHere(query: string): Promise<GeocodeResponse> {
    const apiKey = getApiKey("here")
    if (!apiKey) {
      console.warn("HERE API key not configured, falling back to mock")
      return this.mockSearch(query)
    }

    const url = `https://geocode.search.hereapi.com/v1/geocode?q=${encodeURIComponent(query)}&apikey=${apiKey}&limit=5&in=countryCode:USA`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.items) {
        const suggestions = data.items.map((item: any) => this.parseHereResult(item))
        return { suggestions, status: "success", source: "here" }
      } else {
        return { suggestions: [], status: "error", message: "HERE API error" }
      }
    } catch (error) {
      console.error("HERE geocoding failed:", error)
      return this.mockSearch(query) // Fallback to mock
    }
  }

  private parseHereResult(item: any): AddressSuggestion {
    const address = item.address
    const zipCode = address.postalCode
    const utilityInfo = UTILITY_COMPANIES_DB[zipCode] || {}

    return {
      id: item.id,
      fullAddress: item.title,
      street: `${address.houseNumber || ""} ${address.street || ""}`.trim(),
      city: address.city,
      state: address.state,
      zipCode,
      country: address.countryName,
      coordinates: { lat: item.position.lat, lng: item.position.lng },
      utilityCompany: utilityInfo.name,
      climateZone: utilityInfo.climateZone,
      confidence: item.scoring?.queryScore || 0.8,
      source: "here",
    }
  }

  private async mockSearch(query: string): Promise<GeocodeResponse> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    // Enhanced mock database with more realistic addresses
    const mockDatabase: AddressSuggestion[] = [
      {
        id: "mock_1",
        fullAddress: "123 Main Street, Springfield, IL 62701, USA",
        street: "123 Main Street",
        city: "Springfield",
        state: "IL",
        zipCode: "62701",
        country: "USA",
        coordinates: { lat: 39.7817, lng: -89.6501 },
        utilityCompany: "Ameren Illinois",
        climateZone: "5A",
        confidence: 0.95,
        source: "mock",
      },
      {
        id: "mock_2",
        fullAddress: "456 Oak Avenue, Chicago, IL 60601, USA",
        street: "456 Oak Avenue",
        city: "Chicago",
        state: "IL",
        zipCode: "60601",
        country: "USA",
        coordinates: { lat: 41.8781, lng: -87.6298 },
        utilityCompany: "ComEd",
        climateZone: "5A",
        confidence: 0.92,
        source: "mock",
      },
      {
        id: "mock_3",
        fullAddress: "789 Pine Street, Beverly Hills, CA 90210, USA",
        street: "789 Pine Street",
        city: "Beverly Hills",
        state: "CA",
        zipCode: "90210",
        country: "USA",
        coordinates: { lat: 34.0901, lng: -118.4065 },
        utilityCompany: "Los Angeles Department of Water and Power",
        climateZone: "3B",
        confidence: 0.88,
        source: "mock",
      },
      {
        id: "mock_4",
        fullAddress: "321 Elm Drive, Austin, TX 78701, USA",
        street: "321 Elm Drive",
        city: "Austin",
        state: "TX",
        zipCode: "78701",
        country: "USA",
        coordinates: { lat: 30.2672, lng: -97.7431 },
        utilityCompany: "Austin Energy",
        climateZone: "2A",
        confidence: 0.9,
        source: "mock",
      },
      {
        id: "mock_5",
        fullAddress: "654 Maple Lane, Seattle, WA 98101, USA",
        street: "654 Maple Lane",
        city: "Seattle",
        state: "WA",
        zipCode: "98101",
        country: "USA",
        coordinates: { lat: 47.6062, lng: -122.3321 },
        utilityCompany: "Seattle City Light",
        climateZone: "4C",
        confidence: 0.87,
        source: "mock",
      },
      {
        id: "mock_6",
        fullAddress: "987 Broadway, New York, NY 10001, USA",
        street: "987 Broadway",
        city: "New York",
        state: "NY",
        zipCode: "10001",
        country: "USA",
        coordinates: { lat: 40.7505, lng: -73.9934 },
        utilityCompany: "Consolidated Edison",
        climateZone: "4A",
        confidence: 0.93,
        source: "mock",
      },
    ]

    // Enhanced filtering and ranking
    const filtered = mockDatabase.filter((address) => {
      const searchTerms = query.toLowerCase().split(" ")
      const addressText = address.fullAddress.toLowerCase()

      return searchTerms.some(
        (term) =>
          addressText.includes(term) ||
          address.street.toLowerCase().includes(term) ||
          address.city.toLowerCase().includes(term) ||
          address.zipCode.includes(term),
      )
    })

    // Sort by relevance
    const sorted = filtered
      .sort((a, b) => {
        const aScore = this.calculateRelevanceScore(a, query)
        const bScore = this.calculateRelevanceScore(b, query)
        return bScore - aScore
      })
      .slice(0, 5)

    return { suggestions: sorted, status: "success", source: "mock" }
  }

  private calculateRelevanceScore(address: AddressSuggestion, query: string): number {
    const lowerQuery = query.toLowerCase()
    let score = 0

    // Exact matches get higher scores
    if (address.street.toLowerCase().includes(lowerQuery)) score += 10
    if (address.city.toLowerCase().includes(lowerQuery)) score += 8
    if (address.zipCode.includes(query)) score += 6
    if (address.state.toLowerCase().includes(lowerQuery)) score += 4

    // Partial matches get lower scores
    if (address.fullAddress.toLowerCase().includes(lowerQuery)) score += 2

    // Boost score based on confidence
    score += (address.confidence || 0.5) * 5

    return score
  }

  async reverseGeocode(lat: number, lng: number): Promise<AddressSuggestion | null> {
    try {
      switch (this.config.provider) {
        case "google":
          return this.reverseGeocodeGoogle(lat, lng)
        case "mapbox":
          return this.reverseGeocodeMapbox(lat, lng)
        default:
          return this.reverseGeocodeMock(lat, lng)
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error)
      return this.reverseGeocodeMock(lat, lng) // Fallback to mock
    }
  }

  private async reverseGeocodeGoogle(lat: number, lng: number): Promise<AddressSuggestion | null> {
    const apiKey = getApiKey("google")
    if (!apiKey) return this.reverseGeocodeMock(lat, lng)

    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.results && data.results.length > 0) {
        const result = data.results[0]
        return this.parseGoogleGeocodeResult(result)
      }
    } catch (error) {
      console.error("Google reverse geocoding failed:", error)
    }

    return this.reverseGeocodeMock(lat, lng)
  }

  private parseGoogleGeocodeResult(result: any): AddressSuggestion {
    const components = result.address_components
    const getComponent = (type: string) => {
      const component = components.find((comp: any) => comp.types.includes(type))
      return component?.long_name || ""
    }

    const zipCode = getComponent("postal_code")
    const utilityInfo = UTILITY_COMPANIES_DB[zipCode] || {}

    return {
      id: result.place_id,
      fullAddress: result.formatted_address,
      street: `${getComponent("street_number")} ${getComponent("route")}`.trim(),
      city: getComponent("locality"),
      state: getComponent("administrative_area_level_1"),
      zipCode,
      coordinates: { lat: result.geometry.location.lat, lng: result.geometry.location.lng },
      utilityCompany: utilityInfo.name,
      climateZone: utilityInfo.climateZone,
      confidence: 0.9,
      source: "google_reverse",
    }
  }

  private async reverseGeocodeMapbox(lat: number, lng: number): Promise<AddressSuggestion | null> {
    const apiKey = getApiKey("mapbox")
    if (!apiKey) return this.reverseGeocodeMock(lat, lng)

    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${apiKey}&types=address`

    try {
      const response = await fetch(url)
      const data = await response.json()

      if (data.features && data.features.length > 0) {
        return this.parseMapboxResult(data.features[0])
      }
    } catch (error) {
      console.error("Mapbox reverse geocoding failed:", error)
    }

    return this.reverseGeocodeMock(lat, lng)
  }

  private async reverseGeocodeMock(lat: number, lng: number): Promise<AddressSuggestion | null> {
    // Mock reverse geocoding
    return {
      id: "reverse_mock",
      fullAddress: "Current Location - 123 Your Street, Your City, ST 12345",
      street: "123 Your Street",
      city: "Your City",
      state: "ST",
      zipCode: "12345",
      coordinates: { lat, lng },
      confidence: 0.8,
      source: "mock_reverse",
    }
  }
}

// Create singleton instance
const serverGeocodingService = new ServerGeocodingService()

// Server Actions - these are secure and run on the server
export async function searchAddressesAction(query: string): Promise<GeocodeResponse> {
  return serverGeocodingService.searchAddresses(query)
}

export async function reverseGeocodeAction(lat: number, lng: number): Promise<AddressSuggestion | null> {
  return serverGeocodingService.reverseGeocode(lat, lng)
}
