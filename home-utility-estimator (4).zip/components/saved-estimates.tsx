"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trash2, Calendar, Home, MapPin } from "lucide-react"

interface SavedEstimate {
  homeDetails: any
  regionData: any
  utilities: any[]
  totalCost: number
  timestamp: string
}

export function SavedEstimates() {
  const [savedEstimates, setSavedEstimates] = useState<SavedEstimate[]>([])

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("utilityEstimates") || "[]")
    setSavedEstimates(saved)
  }, [])

  const deleteEstimate = (index: number) => {
    const updated = savedEstimates.filter((_, i) => i !== index)
    setSavedEstimates(updated)
    localStorage.setItem("utilityEstimates", JSON.stringify(updated))
  }

  const clearAll = () => {
    setSavedEstimates([])
    localStorage.removeItem("utilityEstimates")
  }

  if (savedEstimates.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">No saved estimates yet.</p>
          <p className="text-sm text-gray-400 mt-2">Complete an estimate and save it to see it here.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Saved Estimates</h2>
        <Button variant="outline" onClick={clearAll} className="text-red-600 hover:text-red-700">
          Clear All
        </Button>
      </div>

      {savedEstimates.map((estimate, index) => (
        <Card key={index}>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Home className="h-5 w-5" />${estimate.totalCost.toFixed(2)}/month
                </CardTitle>
                <CardDescription className="flex items-center gap-4 mt-2">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {estimate.regionData.name}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {new Date(estimate.timestamp).toLocaleDateString()}
                  </span>
                </CardDescription>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteEstimate(index)}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <div className="font-medium">Size</div>
                <div className="text-gray-600">{estimate.homeDetails.squareFootage} sq ft</div>
              </div>
              <div>
                <div className="font-medium">Type</div>
                <div className="text-gray-600 capitalize">{estimate.homeDetails.homeType}</div>
              </div>
              <div>
                <div className="font-medium">Occupants</div>
                <div className="text-gray-600">{estimate.homeDetails.occupants}</div>
              </div>
              <div>
                <div className="font-medium">Top Utility</div>
                <div className="text-gray-600">
                  {estimate.utilities.reduce((max, utility) => (utility.amount > max.amount ? utility : max)).name}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mt-4">
              {estimate.utilities.slice(0, 3).map((utility: any) => (
                <Badge key={utility.name} variant="secondary">
                  {utility.name}: ${utility.amount.toFixed(2)}
                </Badge>
              ))}
              {estimate.utilities.length > 3 && <Badge variant="outline">+{estimate.utilities.length - 3} more</Badge>}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
