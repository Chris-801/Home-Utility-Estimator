"use client"

import { useEffect } from "react"

export function Analytics() {
  useEffect(() => {
    // Add your analytics code here (Google Analytics, etc.)
    // Example:
    // gtag('config', 'GA_MEASUREMENT_ID')
  }, [])

  return null
}
