"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import type { HomeDetails } from "@/app/page"
import { ArrowRight, Users, HomeIcon, Bath, Bed, Ruler } from "lucide-react"

interface HomeDetailsFormProps {
  homeDetails: HomeDetails
  onUpdate: (details: HomeDetails) => void
  onNext: () => void
}

const appliances = [
  "Dishwasher",
  "Washing Machine",
  "Dryer",
  "Electric Water Heater",
  "Pool/Hot Tub",
  "Electric Vehicle Charger",
  "Home Office Setup",
]

export function HomeDetailsForm({ homeDetails, onUpdate, onNext }: HomeDetailsFormProps) {
  const updateField = (field: keyof HomeDetails, value: any) => {
    onUpdate({ ...homeDetails, [field]: value })
  }

  const toggleAppliance = (appliance: string) => {
    const current = homeDetails.appliances
    const updated = current.includes(appliance) ? current.filter((a) => a !== appliance) : [...current, appliance]
    updateField("appliances", updated)
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="squareFootage" className="flex items-center gap-2">
            <Ruler className="h-4 w-4 text-blue-600" />
            Square Footage
          </Label>
          <div className="flex gap-4 items-center">
            <div className="flex-1">
              <Slider
                id="squareFootage-slider"
                min={300}
                max={5000}
                step={100}
                value={[homeDetails.squareFootage]}
                onValueChange={(value) => updateField("squareFootage", value[0])}
                className="py-4"
              />
            </div>
            <div className="w-24">
              <Input
                id="squareFootage"
                type="number"
                value={homeDetails.squareFootage}
                onChange={(e) => updateField("squareFootage", Number.parseInt(e.target.value) || 0)}
                className="text-right"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="occupants" className="flex items-center gap-2">
            <Users className="h-4 w-4 text-blue-600" />
            Number of Occupants
          </Label>
          <Select
            value={homeDetails.occupants.toString()}
            onValueChange={(value) => updateField("occupants", Number.parseInt(value))}
          >
            <SelectTrigger id="occupants">
              <SelectValue placeholder="Select number of occupants" />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} {num === 1 ? "person" : "people"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bedrooms" className="flex items-center gap-2">
            <Bed className="h-4 w-4 text-blue-600" />
            Bedrooms
          </Label>
          <Select
            value={homeDetails.bedrooms.toString()}
            onValueChange={(value) => updateField("bedrooms", Number.parseInt(value))}
          >
            <SelectTrigger id="bedrooms">
              <SelectValue placeholder="Select number of bedrooms" />
            </SelectTrigger>
            <SelectContent>
              {[0, 1, 2, 3, 4, 5, 6].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} {num === 1 ? "bedroom" : "bedrooms"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bathrooms" className="flex items-center gap-2">
            <Bath className="h-4 w-4 text-blue-600" />
            Bathrooms
          </Label>
          <Select
            value={homeDetails.bathrooms.toString()}
            onValueChange={(value) => updateField("bathrooms", Number.parseFloat(value))}
          >
            <SelectTrigger id="bathrooms">
              <SelectValue placeholder="Select number of bathrooms" />
            </SelectTrigger>
            <SelectContent>
              {[1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} {num === 1 ? "bathroom" : "bathrooms"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <HomeIcon className="h-4 w-4 text-blue-600" />
            Home Type
          </Label>
          <Select value={homeDetails.homeType} onValueChange={(value) => updateField("homeType", value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="apartment">Apartment</SelectItem>
              <SelectItem value="house">House</SelectItem>
              <SelectItem value="condo">Condo</SelectItem>
              <SelectItem value="townhouse">Townhouse</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Heating Type</Label>
          <Select value={homeDetails.heatingType} onValueChange={(value) => updateField("heatingType", value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="electric">Electric</SelectItem>
              <SelectItem value="gas">Natural Gas</SelectItem>
              <SelectItem value="oil">Oil</SelectItem>
              <SelectItem value="heat-pump">Heat Pump</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Cooling Type</Label>
          <Select value={homeDetails.coolingType} onValueChange={(value) => updateField("coolingType", value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="central-ac">Central AC</SelectItem>
              <SelectItem value="window-ac">Window AC</SelectItem>
              <SelectItem value="none">None</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-4">
        <Label>Additional Appliances</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {appliances.map((appliance) => (
            <div key={appliance} className="flex items-center space-x-2">
              <Checkbox
                id={appliance}
                checked={homeDetails.appliances.includes(appliance)}
                onCheckedChange={() => toggleAppliance(appliance)}
              />
              <Label htmlFor={appliance} className="text-sm">
                {appliance}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={onNext} className="flex items-center gap-2">
          Next: Select Region
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
