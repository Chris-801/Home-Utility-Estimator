"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { MapPin, AlertCircle, Zap } from "lucide-react"
import { AddressAutocomplete } from "@/components/address-autocomplete"

interface AddressData {
  street: string
  city: string
  state: string
  zipCode: string
  coordinates?: { lat: number; lng: number }
  utilityCompany?: string
  climateZone?: string
}

interface AddressInputProps {
  onAddressSelect: (address: AddressData) => void
  onSkip: () => void
}

export function AddressInput({ onAddressSelect, onSkip }: AddressInputProps) {
  const [showManualEntry, setShowManualEntry] = useState(false)
  const [manualAddress, setManualAddress] = useState<Partial<AddressData>>({})

  const handleAutocompleteSelect = (suggestion: any) => {
    onAddressSelect({
      street: suggestion.street,
      city: suggestion.city,
      state: suggestion.state,
      zipCode: suggestion.zipCode,
      coordinates: suggestion.coordinates,
      utilityCompany: suggestion.utilityCompany,
      climateZone: suggestion.climateZone,
    })
  }

  const handleManualSubmit = () => {
    if (manualAddress.city && manualAddress.state && manualAddress.zipCode) {
      onAddressSelect({
        street: manualAddress.street || "",
        city: manualAddress.city,
        state: manualAddress.state,
        zipCode: manualAddress.zipCode,
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
          <MapPin className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Enter Your Address</h2>
        <p className="text-gray-600 max-w-md mx-auto">
          Get hyper-local utility rates and climate-adjusted estimates for your exact location
        </p>
      </div>

      {/* Benefits callout */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Zap className="h-5 w-5 text-green-600" />
            <div className="text-sm">
              <div className="font-medium text-green-900">More Accurate Estimates</div>
              <div className="text-green-700">
                Get rates from your actual utility company and climate-adjusted calculations
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {!showManualEntry ? (
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium mb-3 block">Search for your address</Label>
            <AddressAutocomplete
              onAddressSelect={handleAutocompleteSelect}
              placeholder="Start typing your address (e.g., 123 Main St, Springfield, IL)"
            />
          </div>

          <div className="text-center">
            <div className="flex items-center gap-4 my-6">
              <Separator className="flex-1" />
              <span className="text-sm text-gray-500">or</span>
              <Separator className="flex-1" />
            </div>

            <div className="flex justify-center gap-3">
              <Button variant="outline" onClick={() => setShowManualEntry(true)} className="flex items-center gap-2">
                Enter Manually
              </Button>
              <Button variant="ghost" onClick={onSkip} className="flex items-center gap-2">
                Skip & Use Regions
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium mb-3 block">Enter address manually</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="street">Street Address (Optional)</Label>
                <Input
                  id="street"
                  placeholder="123 Main Street"
                  value={manualAddress.street || ""}
                  onChange={(e) => setManualAddress({ ...manualAddress, street: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  placeholder="Springfield"
                  value={manualAddress.city || ""}
                  onChange={(e) => setManualAddress({ ...manualAddress, city: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="state">State *</Label>
                <Input
                  id="state"
                  placeholder="IL"
                  maxLength={2}
                  value={manualAddress.state || ""}
                  onChange={(e) => setManualAddress({ ...manualAddress, state: e.target.value.toUpperCase() })}
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="zipCode">ZIP Code *</Label>
                <Input
                  id="zipCode"
                  placeholder="62701"
                  maxLength={5}
                  value={manualAddress.zipCode || ""}
                  onChange={(e) => setManualAddress({ ...manualAddress, zipCode: e.target.value.replace(/\D/g, "") })}
                />
              </div>
            </div>
          </div>

          <div className="flex justify-center gap-3">
            <Button
              onClick={handleManualSubmit}
              disabled={!manualAddress.city || !manualAddress.state || !manualAddress.zipCode}
              className="flex items-center gap-2"
            >
              Continue with Address
            </Button>
            <Button variant="outline" onClick={() => setShowManualEntry(false)}>
              Back to Search
            </Button>
            <Button variant="ghost" onClick={onSkip}>
              Skip
            </Button>
          </div>
        </div>
      )}

      {/* Privacy notice */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <div className="font-medium text-blue-900 mb-1">Privacy & Security</div>
              <div className="text-blue-700">
                Your address is only used to provide accurate utility estimates. We don't store, share, or sell your
                location data.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick tips */}
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <div className="text-sm">
            <div className="font-medium text-gray-900 mb-2">💡 Tips for better results:</div>
            <ul className="text-gray-700 space-y-1">
              <li>• Include street number and name for best accuracy</li>
              <li>• Use your current location button for instant results</li>
              <li>• ZIP code alone works if you prefer not to share full address</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
