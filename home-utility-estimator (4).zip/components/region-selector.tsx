"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { RegionData } from "@/app/page"
import { ArrowLeft, ArrowRight, MapPin } from "lucide-react"

interface RegionSelectorProps {
  selectedRegion: RegionData
  onRegionChange: (region: RegionData) => void
  onNext: () => void
  onBack: () => void
}

const regions: RegionData[] = [
  {
    name: "Northeast (NY, MA, CT)",
    electricityRate: 0.22,
    gasRate: 1.15,
    waterRate: 0.005,
    sewerRate: 65,
    trashRate: 35,
    internetRate: 75,
  },
  {
    name: "Southeast (FL, GA, SC)",
    electricityRate: 0.12,
    gasRate: 1.05,
    waterRate: 0.003,
    sewerRate: 35,
    trashRate: 20,
    internetRate: 60,
  },
  {
    name: "Midwest (IL, OH, MI)",
    electricityRate: 0.14,
    gasRate: 0.95,
    waterRate: 0.004,
    sewerRate: 40,
    trashRate: 25,
    internetRate: 55,
  },
  {
    name: "Southwest (TX, AZ, NM)",
    electricityRate: 0.13,
    gasRate: 1.0,
    waterRate: 0.006,
    sewerRate: 45,
    trashRate: 30,
    internetRate: 65,
  },
  {
    name: "West Coast (CA, OR, WA)",
    electricityRate: 0.25,
    gasRate: 1.25,
    waterRate: 0.007,
    sewerRate: 70,
    trashRate: 40,
    internetRate: 80,
  },
  {
    name: "Mountain West (CO, UT, ID)",
    electricityRate: 0.15,
    gasRate: 0.9,
    waterRate: 0.004,
    sewerRate: 35,
    trashRate: 25,
    internetRate: 60,
  },
  {
    name: "National Average",
    electricityRate: 0.16,
    gasRate: 1.09,
    waterRate: 0.004,
    sewerRate: 45,
    trashRate: 25,
    internetRate: 65,
  },
]

export function RegionSelector({ selectedRegion, onRegionChange, onNext, onBack }: RegionSelectorProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {regions.map((region) => (
          <Card
            key={region.name}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedRegion.name === region.name ? "ring-2 ring-blue-500 bg-blue-50" : "hover:bg-gray-50"
            }`}
            onClick={() => onRegionChange(region)}
          >
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <MapPin className="h-5 w-5" />
                {region.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                <div>Electricity: ${region.electricityRate.toFixed(3)}/kWh</div>
                <div>Gas: ${region.gasRate.toFixed(2)}/therm</div>
                <div>Water: ${region.waterRate.toFixed(3)}/gal</div>
                <div>Internet: ${region.internetRate}/mo</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        <Button onClick={onNext} className="flex items-center gap-2">
          Calculate Estimate
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
