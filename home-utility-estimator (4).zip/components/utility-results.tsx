"use client"

import React from "react"

import { useRef } from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { HomeDetails, RegionData } from "@/app/page"
import { ArrowLeft, Zap, Flame, Droplets, Wifi, Trash2, Building, Download, Printer, Save, Share2 } from "lucide-react"

interface UtilityResultsProps {
  homeDetails: HomeDetails
  regionData: RegionData
  onBack: () => void
}

interface UtilityEstimate {
  name: string
  amount: number
  icon: React.ReactNode
  description: string
}

function calculateUtilities(home: HomeDetails, region: RegionData): UtilityEstimate[] {
  // Base electricity usage calculation
  let electricityKwh = home.squareFootage * 0.8 // Base usage per sq ft

  // Adjust for heating/cooling
  if (home.heatingType === "electric") electricityKwh += home.squareFootage * 0.3
  if (home.coolingType === "central-ac") electricityKwh += home.squareFootage * 0.4
  if (home.coolingType === "window-ac") electricityKwh += home.squareFootage * 0.2

  // Adjust for occupants
  electricityKwh += home.occupants * 200

  // Adjust for appliances
  const applianceUsage = {
    Dishwasher: 50,
    "Washing Machine": 40,
    Dryer: 80,
    "Electric Water Heater": 400,
    "Pool/Hot Tub": 300,
    "Electric Vehicle Charger": 500,
    "Home Office Setup": 100,
  }

  home.appliances.forEach((appliance) => {
    electricityKwh += applianceUsage[appliance as keyof typeof applianceUsage] || 0
  })

  const electricityCost = electricityKwh * region.electricityRate

  // Gas calculation (if applicable)
  let gasTherm = 0
  if (home.heatingType === "gas") {
    gasTherm = home.squareFootage * 0.02 + home.occupants * 5
  }
  const gasCost = gasTherm * region.gasRate

  // Water calculation
  const waterGallons = home.occupants * 2000 + home.bathrooms * 500
  const waterCost = waterGallons * region.waterRate

  const utilities: UtilityEstimate[] = [
    {
      name: "Electricity",
      amount: electricityCost,
      icon: <Zap className="h-5 w-5" />,
      description: `${Math.round(electricityKwh)} kWh at $${region.electricityRate.toFixed(3)}/kWh`,
    },
    {
      name: "Water",
      amount: waterCost,
      icon: <Droplets className="h-5 w-5" />,
      description: `${Math.round(waterGallons)} gallons at $${region.waterRate.toFixed(3)}/gal`,
    },
    {
      name: "Sewer",
      amount: region.sewerRate,
      icon: <Building className="h-5 w-5" />,
      description: "Fixed monthly rate",
    },
    {
      name: "Trash & Recycling",
      amount: region.trashRate,
      icon: <Trash2 className="h-5 w-5" />,
      description: "Fixed monthly rate",
    },
    {
      name: "Internet",
      amount: region.internetRate,
      icon: <Wifi className="h-5 w-5" />,
      description: "Average broadband rate",
    },
  ]

  if (gasCost > 0) {
    utilities.splice(1, 0, {
      name: "Natural Gas",
      amount: gasCost,
      icon: <Flame className="h-5 w-5" />,
      description: `${Math.round(gasTherm)} therms at $${region.gasRate.toFixed(2)}/therm`,
    })
  }

  return utilities
}

interface PrintableEstimateProps {
  homeDetails: HomeDetails
  regionData: RegionData
  utilities: UtilityEstimate[]
  totalCost: number
}

const PrintableEstimate: React.ForwardRefRenderFunction<HTMLDivElement, PrintableEstimateProps> = (
  { homeDetails, regionData, utilities, totalCost },
  ref,
) => {
  return (
    <div ref={ref}>
      <div className="header">
        <h2>Utility Estimate - {regionData.name}</h2>
        <p>Based on your home details</p>
      </div>

      <div className="total">Total Estimated Monthly Utilities: ${totalCost.toFixed(2)}</div>

      {utilities.map((utility) => (
        <div key={utility.name} className="utility-item">
          <span>{utility.name}</span>
          <span>${utility.amount.toFixed(2)}</span>
        </div>
      ))}

      <div className="details">
        <h3>Estimate Details</h3>
        <div className="details-grid">
          <div>Home Size: {homeDetails.squareFootage.toLocaleString()} sq ft</div>
          <div>Occupants: {homeDetails.occupants} people</div>
          <div>Home Type: {homeDetails.homeType}</div>
          <div>Region: {regionData.name}</div>
        </div>
      </div>
    </div>
  )
}

export const PrintableEstimateComponent = React.forwardRef(PrintableEstimate)

export function UtilityResults({ homeDetails, regionData, onBack }: UtilityResultsProps) {
  const utilities = calculateUtilities(homeDetails, regionData)
  const totalCost = utilities.reduce((sum, utility) => sum + utility.amount, 0)
  const maxCost = Math.max(...utilities.map((u) => u.amount))

  const printRef = useRef<HTMLDivElement>(null)

  const handlePrint = () => {
    const printContent = printRef.current
    if (!printContent) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Utility Estimate - ${regionData.name}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .total { font-size: 24px; font-weight: bold; color: #2563eb; margin: 20px 0; }
          .utility-item { display: flex; justify-content: space-between; padding: 10px; border-bottom: 1px solid #e5e7eb; }
          .details { margin-top: 30px; }
          .details-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 15px; }
          @media print { body { margin: 0; } }
        </style>
      </head>
      <body>
        ${printContent.innerHTML}
      </body>
    </html>
  `)
    printWindow.document.close()
    printWindow.print()
  }

  const handleSaveLocal = () => {
    const estimateData = {
      homeDetails,
      regionData,
      utilities,
      totalCost,
      timestamp: new Date().toISOString(),
    }

    const savedEstimates = JSON.parse(localStorage.getItem("utilityEstimates") || "[]")
    savedEstimates.push(estimateData)
    localStorage.setItem("utilityEstimates", JSON.stringify(savedEstimates))

    // Show success message (you could use a toast here)
    alert("Estimate saved locally! You can access it from your browser storage.")
  }

  const handleDownloadPDF = () => {
    // Use browser's print to PDF functionality
    handlePrint()
    setTimeout(() => {
      alert("Use your browser's print dialog to save as PDF")
    }, 500)
  }

  const handleShare = async () => {
    const shareData = {
      title: "My Utility Estimate",
      text: `My estimated monthly utilities: $${totalCost.toFixed(2)} for a ${homeDetails.squareFootage} sq ft ${homeDetails.homeType} in ${regionData.name}`,
      url: window.location.href,
    }

    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch (err) {
        console.log("Error sharing:", err)
        fallbackShare(shareData.text)
      }
    } else {
      fallbackShare(shareData.text)
    }
  }

  const fallbackShare = (text: string) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert("Estimate details copied to clipboard!")
      })
      .catch(() => {
        alert("Unable to copy to clipboard. Please manually copy the estimate details.")
      })
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <CardHeader>
          <CardTitle className="text-2xl">Monthly Utility Estimate</CardTitle>
          <CardDescription className="text-blue-100">Based on your home in {regionData.name}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold mb-2">${totalCost.toFixed(2)}</div>
          <div className="text-blue-100">Estimated total monthly utilities</div>
        </CardContent>
      </Card>

      {/* Export Actions */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 justify-center">
            <Button onClick={() => handlePrint()} className="flex items-center gap-2">
              <Printer className="h-4 w-4" />
              Print Estimate
            </Button>
            <Button variant="outline" onClick={() => handleSaveLocal()} className="flex items-center gap-2">
              <Save className="h-4 w-4" />
              Save Locally
            </Button>
            <Button variant="outline" onClick={() => handleDownloadPDF()} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
            <Button variant="outline" onClick={() => handleShare()} className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              Share Results
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {utilities.map((utility) => (
          <Card key={utility.name}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg text-blue-600">{utility.icon}</div>
                  <div>
                    <h3 className="font-semibold">{utility.name}</h3>
                    <p className="text-sm text-gray-600">{utility.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">${utility.amount.toFixed(2)}</div>
                  <div className="text-sm text-gray-500">per month</div>
                </div>
              </div>
              <Progress value={(utility.amount / maxCost) * 100} className="h-2" />
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gray-50">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-3">Estimate Details</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="font-medium">Home Size</div>
              <div className="text-gray-600">{homeDetails.squareFootage.toLocaleString()} sq ft</div>
            </div>
            <div>
              <div className="font-medium">Occupants</div>
              <div className="text-gray-600">{homeDetails.occupants} people</div>
            </div>
            <div>
              <div className="font-medium">Home Type</div>
              <div className="text-gray-600 capitalize">{homeDetails.homeType}</div>
            </div>
            <div>
              <div className="font-medium">Region</div>
              <div className="text-gray-600">{regionData.name}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Region Selection
        </Button>
      </div>

      {/* Hidden print component */}
      <div className="hidden">
        <PrintableEstimateComponent
          ref={printRef}
          homeDetails={homeDetails}
          regionData={regionData}
          utilities={utilities}
          totalCost={totalCost}
        />
      </div>
    </div>
  )
}
