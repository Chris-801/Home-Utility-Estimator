"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { LoadingSpinner } from "@/components/loading-spinner"
import { searchAddressesAction, reverseGeocodeAction, type AddressSuggestion } from "@/lib/geocoding-server"
import { MapPin, Search, Navigation, X, Shield, AlertTriangle } from "lucide-react"

interface AddressAutocompleteProps {
  onAddressSelect: (address: AddressSuggestion) => void
  placeholder?: string
  className?: string
}

export function AddressAutocomplete({
  onAddressSelect,
  placeholder = "Start typing your address...",
  className,
}: AddressAutocompleteProps) {
  const [query, setQuery] = useState("")
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const [error, setError] = useState<string | null>(null)

  const inputRef = useRef<HTMLInputElement>(null)
  const suggestionsRef = useRef<HTMLDivElement>(null)
  const debounceRef = useRef<NodeJS.Timeout>()

  // Debounced search function using server action
  const searchAddresses = async (searchQuery: string) => {
    if (searchQuery.length < 3) {
      setSuggestions([])
      setShowSuggestions(false)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await searchAddressesAction(searchQuery)

      if (response.status === "success") {
        setSuggestions(response.suggestions)
        setShowSuggestions(true)
        setSelectedIndex(-1)
      } else if (response.status === "rate_limit") {
        setError("Too many requests. Please wait a moment and try again.")
        setSuggestions([])
        setShowSuggestions(false)
      } else if (response.status === "no_results") {
        setSuggestions([])
        setShowSuggestions(false)
      } else {
        setError(response.message || "Failed to search addresses")
        setSuggestions([])
        setShowSuggestions(false)
      }
    } catch (err) {
      setError("Service temporarily unavailable. Please try again.")
      setSuggestions([])
      setShowSuggestions(false)
    } finally {
      setIsLoading(false)
    }
  }

  // Handle input changes with debouncing
  const handleInputChange = (value: string) => {
    setQuery(value)

    // Clear previous debounce
    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }

    // Set new debounce
    debounceRef.current = setTimeout(() => {
      searchAddresses(value)
    }, 300)
  }

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions || suggestions.length === 0) return

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault()
        setSelectedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0))
        break
      case "ArrowUp":
        e.preventDefault()
        setSelectedIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1))
        break
      case "Enter":
        e.preventDefault()
        if (selectedIndex >= 0 && selectedIndex < suggestions.length) {
          handleSelectAddress(suggestions[selectedIndex])
        }
        break
      case "Escape":
        setShowSuggestions(false)
        setSelectedIndex(-1)
        break
    }
  }

  // Handle address selection
  const handleSelectAddress = (address: AddressSuggestion) => {
    setQuery(address.fullAddress)
    setShowSuggestions(false)
    setSelectedIndex(-1)
    onAddressSelect(address)
  }

  // Get user's current location using server action
  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by this browser")
      return
    }

    setIsLoading(true)
    setError(null)

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const address = await reverseGeocodeAction(position.coords.latitude, position.coords.longitude)

          if (address) {
            handleSelectAddress(address)
          } else {
            setError("Could not determine address for current location")
          }
        } catch (err) {
          setError("Failed to get address for current location")
        } finally {
          setIsLoading(false)
        }
      },
      (error) => {
        let errorMessage = "Unable to get your location"
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied. Please enable location services."
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable."
            break
          case error.TIMEOUT:
            errorMessage = "Location request timed out."
            break
        }
        setError(errorMessage)
        setIsLoading(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
      },
    )
  }

  // Clear input
  const clearInput = () => {
    setQuery("")
    setSuggestions([])
    setShowSuggestions(false)
    setSelectedIndex(-1)
    setError(null)
    inputRef.current?.focus()
  }

  // Click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <div className={`relative ${className}`}>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            ref={inputRef}
            type="text"
            placeholder={placeholder}
            value={query}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => {
              if (suggestions.length > 0) {
                setShowSuggestions(true)
              }
            }}
            className="pr-8"
          />

          {/* Loading spinner or clear button */}
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2">
            {isLoading ? (
              <LoadingSpinner size="sm" />
            ) : query ? (
              <Button variant="ghost" size="sm" onClick={clearInput} className="h-6 w-6 p-0 hover:bg-gray-100">
                <X className="h-3 w-3" />
              </Button>
            ) : (
              <Search className="h-4 w-4 text-gray-400" />
            )}
          </div>
        </div>

        <Button
          variant="outline"
          onClick={getCurrentLocation}
          disabled={isLoading}
          className="flex items-center gap-2 whitespace-nowrap"
        >
          <Navigation className="h-4 w-4" />
          Use Current Location
        </Button>
      </div>

      {/* Service status */}
      <div className="mt-1 text-xs text-gray-500 flex items-center gap-1">
        <Shield className="h-3 w-3" />
        Secure server-side geocoding
      </div>

      {/* Error message */}
      {error && (
        <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Suggestions dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div
          ref={suggestionsRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-auto"
        >
          {suggestions.map((suggestion, index) => (
            <div
              key={suggestion.id}
              className={`p-3 cursor-pointer border-b border-gray-100 last:border-b-0 hover:bg-gray-50 ${
                index === selectedIndex ? "bg-blue-50 border-blue-200" : ""
              }`}
              onClick={() => handleSelectAddress(suggestion)}
            >
              <div className="flex items-start gap-3">
                <MapPin className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-gray-900 truncate">{suggestion.street}</div>
                  <div className="text-sm text-gray-600">
                    {suggestion.city}, {suggestion.state} {suggestion.zipCode}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    {suggestion.utilityCompany && (
                      <Badge variant="secondary" className="text-xs">
                        {suggestion.utilityCompany}
                      </Badge>
                    )}
                    {suggestion.confidence && (
                      <Badge variant="outline" className="text-xs">
                        {Math.round(suggestion.confidence * 100)}% match
                      </Badge>
                    )}
                    {suggestion.source && (
                      <Badge variant="outline" className="text-xs">
                        {suggestion.source}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* No results message */}
      {showSuggestions && suggestions.length === 0 && query.length >= 3 && !isLoading && !error && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg p-4 text-center text-gray-500">
          No addresses found. Try a different search term or check your spelling.
        </div>
      )}
    </div>
  )
}
