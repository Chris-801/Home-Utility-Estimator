"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddressInput } from "@/components/address-input"
import { HomeDetailsForm } from "@/components/home-details-form"
import { RegionSelector } from "@/components/region-selector"
import { UtilityResults } from "@/components/utility-results"
import { SavedEstimates } from "@/components/saved-estimates"
import { Calculator, Home, MapPin, DollarSign, Save } from "lucide-react"
import { getUtilityRatesByAddress } from "@/lib/address-utils"

export interface HomeDetails {
  squareFootage: number
  bedrooms: number
  bathrooms: number
  occupants: number
  homeType: "apartment" | "house" | "condo" | "townhouse"
  heatingType: "electric" | "gas" | "oil" | "heat-pump"
  coolingType: "central-ac" | "window-ac" | "none"
  appliances: string[]
}

export interface RegionData {
  name: string
  electricityRate: number
  gasRate: number
  waterRate: number
  sewerRate: number
  trashRate: number
  internetRate: number
  utilityCompany?: string
  climateZone?: string
}

interface AddressData {
  street: string
  city: string
  state: string
  zipCode: string
  coordinates?: { lat: number; lng: number }
  utilityCompany?: string
  climateZone?: string
}

const defaultHomeDetails: HomeDetails = {
  squareFootage: 1200,
  bedrooms: 2,
  bathrooms: 2,
  occupants: 2,
  homeType: "apartment",
  heatingType: "electric",
  coolingType: "central-ac",
  appliances: [],
}

const defaultRegion: RegionData = {
  name: "National Average",
  electricityRate: 0.16,
  gasRate: 1.09,
  waterRate: 0.004,
  sewerRate: 45,
  trashRate: 25,
  internetRate: 65,
}

export default function HomePage() {
  const [homeDetails, setHomeDetails] = useState<HomeDetails>(defaultHomeDetails)
  const [selectedRegion, setSelectedRegion] = useState<RegionData>(defaultRegion)
  const [selectedAddress, setSelectedAddress] = useState<AddressData | null>(null)
  const [activeTab, setActiveTab] = useState("address")

  const handleAddressSelect = (address: AddressData) => {
    setSelectedAddress(address)

    // Try to get specific utility rates for this address
    const localRates = getUtilityRatesByAddress(address)
    if (localRates) {
      setSelectedRegion({
        name: `${address.city}, ${address.state}`,
        ...localRates,
      })
    }

    setActiveTab("home")
  }

  const handleSkipAddress = () => {
    setSelectedAddress(null)
    setActiveTab("region")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Calculator className="h-8 w-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">Home Utility Estimator</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Get accurate estimates for your monthly utility bills based on your home details and local rates
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="address" className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Address
              </TabsTrigger>
              <TabsTrigger value="home" className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                Home Details
              </TabsTrigger>
              <TabsTrigger value="region" className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Location
              </TabsTrigger>
              <TabsTrigger value="results" className="flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Estimate
              </TabsTrigger>
              <TabsTrigger value="saved" className="flex items-center gap-2">
                <Save className="h-4 w-4" />
                Saved
              </TabsTrigger>
            </TabsList>

            <TabsContent value="address">
              <Card>
                <CardContent className="p-6">
                  <AddressInput onAddressSelect={handleAddressSelect} onSkip={handleSkipAddress} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="home">
              <Card>
                <CardHeader>
                  <CardTitle>Home Details</CardTitle>
                  <CardDescription>
                    {selectedAddress
                      ? `Tell us about your home at ${selectedAddress.city}, ${selectedAddress.state}`
                      : "Tell us about your home to get accurate utility estimates"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <HomeDetailsForm
                    homeDetails={homeDetails}
                    onUpdate={setHomeDetails}
                    onNext={() => setActiveTab(selectedAddress ? "results" : "region")}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="region">
              <Card>
                <CardHeader>
                  <CardTitle>Select Your Region</CardTitle>
                  <CardDescription>Choose your location to get region-specific utility rates</CardDescription>
                </CardHeader>
                <CardContent>
                  <RegionSelector
                    selectedRegion={selectedRegion}
                    onRegionChange={setSelectedRegion}
                    onNext={() => setActiveTab("results")}
                    onBack={() => setActiveTab("home")}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="results">
              <UtilityResults
                homeDetails={homeDetails}
                regionData={selectedRegion}
                onBack={() => setActiveTab(selectedAddress ? "home" : "region")}
              />
            </TabsContent>

            <TabsContent value="saved">
              <Card>
                <CardHeader>
                  <CardTitle>Saved Estimates</CardTitle>
                  <CardDescription>View and manage your previously saved utility estimates</CardDescription>
                </CardHeader>
                <CardContent>
                  <SavedEstimates />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
