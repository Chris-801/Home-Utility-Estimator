import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ErrorBoundary } from "@/components/error-boundary"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Home Utility Estimator - Calculate Monthly Utility Bills",
  description:
    "Get accurate estimates for your monthly utility bills including electricity, gas, water, and internet based on your home details and regional rates.",
  keywords: "utility bills, home expenses, electricity calculator, gas bills, water bills, budget planning",
  authors: [{ name: "Home Utility Estimator" }],
  openGraph: {
    title: "Home Utility Estimator",
    description: "Calculate your monthly utility bills with regional accuracy",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ErrorBoundary>{children}</ErrorBoundary>
      </body>
    </html>
  )
}
